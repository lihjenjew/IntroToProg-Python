
'''
dev:lihjen jew
des: display a menu for user to execute following fuctions
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program

'''
# open prepare ToDo.txt file
objFileName="D:\\uwdata\Module05\ToDo.txt"
strData=""
dicTable={}
# read in current content
#open ToDo.txt file for reading
objFile=open(objFileName,"r")
for line in objFile:
    lstData=line.split(",")#seperate line into two data
    dicTable[lstData[0].strip()]=lstData[1].strip()#assign key and value to dictionary


objFile.close()
'''
#task 2 Show current data
for strKey, strValue in dicTable.items():
    print("content="+strKey,"priority="+strValue)
'''
#select menu for choosing
while(True):
    print("1) Show current data"+"\n")
    print("2) Add a new item"+"\n")
    print("3) Remove an existing item"+"\n")
    print("4) Save Data to File."+"\n")
    print("5) Exit Program"+"\n")

    intChoice=int(input("What is your choice[1-5]"))
#show current data if user selects 1
    if(intChoice ==1):
        for strKey, strValue in dicTable.items():
            print("content="+strKey,"priority="+strValue)
        continue
#add new item if user select 2
    elif (intChoice==2):
        strTask=input("key in the task")
        strPriority=input("key in the task priority")
        dicTable[strTask]=strPriority
        print(dicTable)
        continue
#remove and existing item if user selects 3
    elif (intChoice == 3):

        for strKey, strValue in dicTable.items():
            print("content="+strKey,"priority="+strValue)

        strDel=input("which item would you like to remove")
        if (strDel in dicTable):
            del dicTable[strDel]
            print(dicTable)
        else:
            print("Sorry I　can't find the item to remove")
        continue
#save data to file ToDo.txt if user selects 4
    elif(intChoice == 4):
        objFile=open(objFileName,"w")
        for strKey, strValue in dicTable.items():
            objFile.write(strKey+","+strValue+"\n")
            #print("content="+strKey,"priority="+strValue)
        objFile.close()
        print("Data Saved")
        continue
#exit program if user selects 5
    elif(intChoice == 5):
        print("Exit  program")
        break






